//--------------------------------------------------------------------------------
// 
// Filename    : UpdateServer.cpp 
// Written By  : Reiot
// 
//--------------------------------------------------------------------------------

// include files
#include <fstream>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>

#include "UpdateServer.h"
#include "Assert.h"
#include "SystemAPI.h"
#include "Properties.h"
#include "UpdateServerPlayer.h"


//--------------------------------------------------------------------------------
//
// constructor
//
//--------------------------------------------------------------------------------
UpdateServer::UpdateServer ()
	throw ( Error )
: m_pServerSocket(NULL)
{
	__BEGIN_TRY

	try {

		// create server socket
		m_pServerSocket = new ServerSocket( g_pConfig->getPropertyInt("Port") );

	} catch ( NoSuchElementException & nsee ) {

		throw Error(nsee.toString());

	}

	__END_CATCH
}


//--------------------------------------------------------------------------------
//
// destructor
//
//--------------------------------------------------------------------------------
UpdateServer::~UpdateServer ()
	throw ( Error )
{
	__BEGIN_TRY

	if ( m_pServerSocket != NULL ) {
		delete m_pServerSocket;
		m_pServerSocket = NULL;
	}

	__END_CATCH
}


//--------------------------------------------------------------------------------
//
// initialize game server
//
//--------------------------------------------------------------------------------
void UpdateServer::init ()
	 throw ( Error )
{
	__BEGIN_TRY

	sysinit();

	__END_CATCH
}


//--------------------------------------------------------------------------------
//
// start game server
//
//--------------------------------------------------------------------------------
void UpdateServer::start ()
	 throw ( Error )
{
	__BEGIN_TRY

	run();
		
	__END_CATCH
}


//--------------------------------------------------------------------------------
//
// stop game server
//
//--------------------------------------------------------------------------------
void UpdateServer::stop ()
	 throw ( Error )
{
	__BEGIN_TRY
	__END_CATCH
}


//--------------------------------------------------------------------------------
//
// main loop
//
//--------------------------------------------------------------------------------
void UpdateServer::run ()
	 throw ()
{
	try {

		// main loop
		while ( true ) {

			//cout << endl << "waiting for connection..." << endl;

			// blocking client socket
			Socket * pSocket = NULL;
			try {
				pSocket = m_pServerSocket->accept();
			} catch ( Throwable & t ) {
				continue;
			}

			if( pSocket == NULL ) continue;

/*
			pSocket->setNonBlocking(false);
			// ������ ���۸� �ø���.
			pSocket->setSendBufferSize(60000000);
			pSocket->setReceiveBufferSize(100000000);
*/

			//cout << "NEW CONNECTION FROM " << pSocket->getHost().c_str() << ":" << pSocket->getPort() << endl;

			//cout << "Socket Send Buffer Size " << pSocket->getSendBufferSize() << endl;
			//cout << "Socket Receive Buffer Size " << pSocket->getReceiveBufferSize() << endl;

			UpdateServerPlayer * pPlayer = new UpdateServerPlayer( pSocket );
			pPlayer->setPlayerStatus( USPS_BEGIN_SESSION );

			//--------------------------------------------------------------------------------
			// ��Ȱ�� ������Ʈ�� ���ؼ�, select ��� fork()�� ����ؼ� 1:1 ������ �����Ѵ�.
			//--------------------------------------------------------------------------------
			if ( SystemAPI::fork_ex() == 0 ) { // case of child

				//cout << "FORK PROCESS[" << getpid() << "] HANDLE " << pSocket->getHost() << endl;

				try {
					while ( true ) {
						pPlayer->processInput();
						pPlayer->processCommand();
						pPlayer->processOutput();
					}
				} catch ( ConnectException & ce ) {
					//cout << ce.toString() << endl;
				} catch ( Throwable & t ) {
					//cout << t.toString() << endl;
				}

				delete pSocket;

				//cout << "CHILD PROCESS EXIT" << endl;

				// ������ ����� ���μ����� �����Ѵ�.
				exit(0);

			} else { // case of parent

				//cout << "PARENT CLOSE CLIENT SOCKET" << endl;
				delete pSocket;
			}

		}//while

	} catch ( Throwable & t ) {
		//cout << t.toString() << endl;
	} catch ( exception & e ) {
		//cout << e.what() << endl;
	}
}


//--------------------------------------------------------------------------------
//
// �ý��� ������ �ʱ�ȭ
//
//--------------------------------------------------------------------------------
void UpdateServer::sysinit()
	throw ( Error )
{
	__BEGIN_TRY

	signal( SIGPIPE , SIG_IGN );	// �̰Ŵ� ���� �߻��� ��
	signal( SIGALRM , SIG_IGN );	// �˶� �ϴ� ���� ����, ���ǻ�
	signal( SIGCHLD , SIG_IGN );	// fork �ϴ� ���� ����, ���ǻ�

	__END_CATCH
}


//--------------------------------------------------------------------------------
// 
// ���߿� �ַܼ� ����� �ʿ䰡 ������ ��ŭ �������� �Ǹ�, 
// �� �Լ��� ȣ���ϵ��� �Ѵ�.
// 
//--------------------------------------------------------------------------------
void UpdateServer::goBackground ()
	throw ( Error )
{
	__BEGIN_TRY

	int forkres = SystemAPI::fork_ex();

	if ( forkres == 0 ) {
		// case of child process
		close( 0 );
		close( 1 );
		close( 2 );
	} else {
		// case of parent process
		exit(0);
	}

	__END_CATCH
}


// global variable declaration
UpdateServer * g_pUpdateServer = NULL;
